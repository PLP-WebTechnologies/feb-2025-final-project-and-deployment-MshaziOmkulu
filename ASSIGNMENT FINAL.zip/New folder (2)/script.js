// script.js

document.addEventListener("DOMContentLoaded", function () {
    // Tabs functionality
    const tabButtons = document.querySelectorAll(".tab-button");
    const postsContainer = document.querySelector(".posts-container");
  
    const posts = [
      { title: "JavaScript Tips", category: "tech", content: "Learn ES6 features like arrow functions, destructuring, and more." },
      { title: "Trip to Cape Town", category: "travel", content: "I visited Table Mountain and enjoyed stunning coastal views." },
      { title: "Healthy Habits", category: "lifestyle", content: "Daily journaling and hydration are key to well-being." },
      { title: "CSS Grid vs Flexbox", category: "tech", content: "Grid is better for layout, Flexbox for UI components." },
      { title: "Bali Adventure", category: "travel", content: "Surfing, temples, and tropical food made Bali unforgettable." }
    ];
  
    function displayPosts(filter) {
      postsContainer.innerHTML = "";
      const filtered = filter === "all" ? posts : posts.filter(p => p.category === filter);
  
      filtered.forEach(post => {
        const card = document.createElement("div");
        card.className = "post-card";
        card.innerHTML = `<h3>${post.title}</h3><p>${post.content}</p><span class="tag">${post.category}</span>`;
        postsContainer.appendChild(card);
      });
    }
  
    tabButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        document.querySelector(".tab-button.active").classList.remove("active");
        btn.classList.add("active");
        displayPosts(btn.dataset.category);
      });
    });
  
    displayPosts("all");
  
    // Slideshow functionality
    const images = [
      "https://picsum.photos/id/1011/800/400",
      "https://picsum.photos/id/1015/800/400",
      "https://picsum.photos/id/1016/800/400"
    ];
    let currentIndex = 0;
    const slide = document.getElementById("slide");
  
    function showSlide(index) {
      slide.src = images[index];
    }
  
    document.getElementById("prevSlide").onclick = () => {
      currentIndex = (currentIndex - 1 + images.length) % images.length;
      showSlide(currentIndex);
    };
  
    document.getElementById("nextSlide").onclick = () => {
      currentIndex = (currentIndex + 1) % images.length;
      showSlide(currentIndex);
    };
  
    // Dark mode toggle
    document.getElementById("darkModeToggle").addEventListener("click", () => {
      document.body.classList.toggle("dark");
    });
  
    // Contact form validation
    const form = document.getElementById("contactForm");
    form.addEventListener("submit", function (e) {
      e.preventDefault();
  
      let valid = true;
      form.querySelectorAll("input, textarea").forEach((field) => {
        const errorDiv = field.nextElementSibling;
        if (!field.checkValidity()) {
          errorDiv.textContent = `Please enter a valid ${field.name}`;
          valid = false;
        } else {
          errorDiv.textContent = "";
        }
      });
  
      if (valid) {
        document.getElementById("formSuccess").textContent = "Thank you! Your message has been sent.";
        form.reset();
      } else {
        document.getElementById("formSuccess").textContent = "";
      }
    });
  });
  